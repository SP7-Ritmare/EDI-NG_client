/**
 * Created by fabio on 20/11/14.
 */

var defaults = {
    metadataEndpoint: "https://adamassoft.it/jbossTest/edi/",
    requiresValidation: "true",
    ediVersion: "2.00",
    controlCSS: "form-control",
    controlGroupCSS: "input-group",
    labelCSS: "form-label"
}